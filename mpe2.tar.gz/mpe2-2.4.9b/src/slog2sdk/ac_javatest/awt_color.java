public class awt_color {
    public static final void main( String[] args ) {
         System.out.println( "blue =" + java.awt.Color.blue );
    }
}
